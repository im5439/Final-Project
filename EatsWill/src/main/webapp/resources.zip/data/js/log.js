function log(msg){
	
	var consoleE = document.getElementById("console");
	consoleE.innerHTML += msg +"<br/>";
	
	
}